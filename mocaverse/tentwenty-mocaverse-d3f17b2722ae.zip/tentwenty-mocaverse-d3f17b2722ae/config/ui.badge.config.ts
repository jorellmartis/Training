export default {
  paddingTop: "5px",
  paddingBottom: "5px",
  paddingLeft: "12px",
  paddingRight: "12px",
  borderRadius: "13px",

  background: "$colors$white100",
  fontColor: "$colors$white",

  fontSize: "1.1rem",
};
