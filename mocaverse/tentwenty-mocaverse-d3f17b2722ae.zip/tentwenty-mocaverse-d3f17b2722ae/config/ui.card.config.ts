export default {
  borderRadius: "$radius$md",
  // Padding Per size
  padding: "12px",
  paddingBig: "20px",
  background: "$colors$black160",
};
