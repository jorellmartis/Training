export default {
  hr: "#4B7867",

  finance: "#4C5E75",

  corporate: "#846067",

  manager: "#BFA665",
};
