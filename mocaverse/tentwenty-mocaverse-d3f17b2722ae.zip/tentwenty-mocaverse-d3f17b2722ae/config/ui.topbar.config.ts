export default {
  // Size
  height: "84px",
  background: "transparent", //TODO: Update to colors
  padding: "10px",
};
