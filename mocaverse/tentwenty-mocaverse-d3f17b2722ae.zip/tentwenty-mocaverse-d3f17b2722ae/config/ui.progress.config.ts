export default {
  height: "2px",
  background: "$colors$white100",
};
