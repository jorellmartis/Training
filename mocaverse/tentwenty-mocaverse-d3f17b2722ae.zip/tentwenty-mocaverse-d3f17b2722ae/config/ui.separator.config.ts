export default {
  height: "1px",
  lineColor: "$colors$white100",
  marginTop: "10px",
  marginBottom: "10px",
};
