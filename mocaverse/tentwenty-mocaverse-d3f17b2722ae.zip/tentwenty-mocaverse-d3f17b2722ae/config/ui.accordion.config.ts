export default {
  // Header
  headerBackground: "transparent",
  triggerPadding: "0 0 20px",
  triggerFontSize: "$typography$fontSizeH7",
  triggerFontColor: "$colors$white",
};
