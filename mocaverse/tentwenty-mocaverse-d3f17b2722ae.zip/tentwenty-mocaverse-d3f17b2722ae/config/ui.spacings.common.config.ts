export default {
  cardColumnGap: "15px",
};
