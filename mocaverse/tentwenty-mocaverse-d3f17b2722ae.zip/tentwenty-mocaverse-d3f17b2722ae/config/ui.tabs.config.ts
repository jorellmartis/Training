export default {
  triggerBackground: "transparent",
  triggerPadding: "6px 0",
  triggerSpacing: "23px",
  triggerFontColor: "$colors$white",
  triggerFontSize: "$typography$fontSizeH7",
  triggerActiveBorder: "$colors$white",
};
